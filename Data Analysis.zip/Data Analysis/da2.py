# 📊 Simple Classification from lebin.csv with Confusion Matrix

import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns

# Step 1: Load the dataset
data = pd.read_csv("/mnt/data/lebin.csv")
data.columns = data.columns.str.lower().str.replace(" ", "_")
print("✅ Data loaded and column names cleaned.")

# Step 2: Convert 'subscription_date' and create target column
if 'subscription_date' in data.columns:
    data['subscription_date'] = pd.to_datetime(data['subscription_date'], errors='coerce')
    data['target'] = (data['subscription_date'] > '2021-01-01').astype(int)
    print("✅ Target column created based on 'subscription_date'.")
else:
    print("⚠️ 'subscription_date' column not found.")

# Step 3: Extract email domain and encode categorical features
if 'email' in data.columns:
    data['email_domain'] = data['email'].astype(str).apply(lambda x: x.split('@')[-1])
    print("✅ Email domain extracted.")

le = LabelEncoder()
for col in ['city', 'country', 'email_domain']:
    if col in data.columns:
        data[col] = le.fit_transform(data[col].astype(str))
        print(f"✅ '{col}' column encoded.")

# Step 4: Create additional feature and prepare data
if 'subscription_date' in data.columns:
    data['days_subscribed'] = (pd.Timestamp.now() - data['subscription_date']).dt.days

# Step 5: Define feature list and check if valid
features = []
for col in ['city', 'country', 'days_subscribed', 'email_domain']:
    if col in data.columns:
        features.append(col)

if 'target' in data.columns and len(features) > 0:
    # Scale and split data
    X = StandardScaler().fit_transform(data[features])
    y = data['target']
    X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)

    # Step 6: Train model
    model = RandomForestClassifier()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    # Step 7: Print classification report
    print("\n📊 Classification Report:")
    print(classification_report(y_test, y_pred))

    # Step 8: Display confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    labels = ['Not Recent (0)', 'Recent (1)']

    plt.figure(figsize=(6, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='YlGnBu', xticklabels=labels, yticklabels=labels, cbar=False)
    plt.title("🧩 Confusion Matrix - Recent Subscriber Classification")
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.tight_layout()
    plt.show()
else:
    print("❌ Model cannot be trained. Missing required columns or features.")
