import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# Step 1: Load the dataset
data = pd.read_csv("/mnt/data/lebin.csv")
data.columns = data.columns.str.lower().str.replace(" ", "_")

# Step 2: Convert 'subscription_date' and create target column
if 'subscription_date' in data.columns:
    data['subscription_date'] = pd.to_datetime(data['subscription_date'], errors='coerce')
    data['target'] = (data['subscription_date'] > '2021-01-01').astype(int)
    print("✅ 'subscription_date' converted and 'target' column created.")
else:
    print("⚠️ 'subscription_date' column not found.")

# Step 3: Encode 'city' and 'country' if present
le = LabelEncoder()
if 'city' in data.columns:
    data['city'] = le.fit_transform(data['city'].astype(str))
    print("✅ 'city' column encoded.")

if 'country' in data.columns:
    data['country'] = le.fit_transform(data['country'].astype(str))
    print("✅ 'country' column encoded.")

# Step 4: Calculate days since subscription
if 'subscription_date' in data.columns:
    data['days_subscribed'] = (pd.Timestamp.now() - data['subscription_date']).dt.days
    print("✅ 'days_subscribed' column added.")

# Step 5: Select features
features = []
if 'city' in data.columns:
    features.append('city')
if 'country' in data.columns:
    features.append('country')
if 'days_subscribed' in data.columns:
    features.append('days_subscribed')

if 'target' in data.columns and len(features) >= 2:
    X = data[features]
    y = data['target']

    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train the model
    model = RandomForestClassifier(random_state=0)
    model.fit(X_train, y_train)

    # Make predictions
    y_pred = model.predict(X_test)

    # Show report and confusion matrix
    print("\n📊 Classification Report:")
    print(classification_report(y_test, y_pred))

    cm = confusion_matrix(y_test, y_pred)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.title("Confusion Matrix")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.tight_layout()
    plt.show()
else:
    print("❌ Not enough valid data to train the model.")
